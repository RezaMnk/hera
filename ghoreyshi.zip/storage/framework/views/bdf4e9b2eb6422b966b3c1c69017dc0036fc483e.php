<?php $__env->startSection('title', 'مقالات'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280 = $component; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['title' => 'مقالات','desc' => 'مقالات تخصصی'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280)): ?>
<?php $component = $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280; ?>
<?php unset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- latest posts -->
    <div class="latest-posts mt-150 mb-150">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-latest-posts">
                            <a href="<?php echo e(route('home.post', $post->slug)); ?>">
                                <div class="latest-posts-bg" style="background-image: url('<?php echo e($post->get_image()); ?>')"></div>
                            </a>
                            <div class="posts-text-box">
                                <h3>
                                    <a href="<?php echo e(route('home.post', $post->slug)); ?>">
                                        <?php echo e($post->title); ?>

                                    </a>
                                </h3>
                                <p class="blog-meta">
                                    <span class="date">
                                    <i class="fas fa-calendar"></i>
                                    <?php echo e($post->created_at()); ?>

                                </span>
                                </p>
                                <p class="excerpt">
                                    <?php echo e(Str::limit(strip_tags($post->text), 150)); ?>

                                </p>
                                <a href="<?php echo e(route('home.post', $post->slug)); ?>" class="read-more-btn icon-btn">
                                    ادامه مطلب
                                    <i class="fas fa-angle-left"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row">
                <div class="col-lg-12 text-center">
                    <?php echo e($posts->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <!-- end latest posts -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/home/posts.blade.php ENDPATH**/ ?>