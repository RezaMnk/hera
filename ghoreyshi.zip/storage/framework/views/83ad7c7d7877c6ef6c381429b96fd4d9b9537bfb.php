<?php $__env->startSection('title', 'ایجاد مقاله'); ?>

<?php $__env->startSection('content'); ?>
    <!-- row : start  -->
    <form action="<?php echo e(route('admin.posts.update', $post->id)); ?>" method="post" class="row" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <!-- right col start -->
        <div class="col-12 col-md-9">

            <div class="card d-block d-md-none">
                <div class="card-body row">
                    <div class="col-4">
                        <a href="<?php echo e(route('admin.posts.index')); ?>">
                            <button type="button" class="btn btn-danger btn-block">لغو</button>
                        </a>
                    </div>
                    <div class="col-8">
                        <button type="submit" name="status" value="1" class="btn btn-success btn-block">بروزرسانی</button>
                    </div>
                    <div class="col-12 mt-4">
                        <a href="<?php echo e(route('home.post', $post->slug)); ?>" target="_blank">
                            <button type="button" class="btn btn-outline-secondary btn-block">مشاهده مقاله</button>
                        </a>
                    </div>
                </div>
            </div>

            <!-- title card : start  -->
            <div class="card">
                <div class="card-body">
                    <label for="title">عنوان مقاله</label>
                    <input type="text" id="title" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="عنوان" value="<?php echo e(old('title') ?: $post->title); ?>" required>

                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- title card : end  -->

            <!-- content card : start  -->
            <div class="card">
                <div class="card-body">
                    <label>متن</label>
                    <textarea id="text" name="text" <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> class="is-invalid" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>><?php echo e(old('text') ?: $post->text); ?></textarea>

                    <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- content card : end  -->
        </div>
        <!-- right col end -->

        <!-- left col start -->
        <div class="col-12 col-md-3">
            <!-- detail card : start  -->
            <div class="card d-none d-md-block">
                <div class="card-body row">
                    <div class="col-4">
                        <a href="<?php echo e(route('admin.posts.index')); ?>">
                            <button type="button" class="btn btn-danger btn-block">لغو</button>
                        </a>
                    </div>
                    <div class="col-8">
                        <button type="submit" name="status" value="1" class="btn btn-success btn-block">بروزرسانی</button>
                    </div>
                    <div class="col-12 mt-4">
                        <a href="<?php echo e(route('home.post', $post->slug)); ?>" target="_blank">
                            <button type="button" class="btn btn-outline-secondary btn-block">مشاهده مقاله</button>
                        </a>
                    </div>
                </div>
            </div>
            <!-- detail card : end  -->
            <!-- image card : start -->
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">تصویر مقاله</h6>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image" id="post-image-input" accept="image/*">
                        <label class="custom-file-label" for="post-image-input">انتخاب فایل تصویر</label>
                    </div>
                    <div class="mt-4">
                        <img src="<?php echo e($post->get_image()); ?>" id="post-image" class="w-100 shadow-sm rounded" alt="<?php echo e($post->title); ?>">
                    </div>

                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- image card : end -->
        </div>
        <!-- left col : end -->
    </form>
    <!-- row : end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
    <script>
        let image_input = document.querySelector('#post-image-input');
        let image = document.querySelector('#post-image');

        image_input.addEventListener('change', function (elem) {
            const [file] = image_input.files
            if (file) {
                image.style.transition = "opacity .1s ease";

                image.style.opacity = '0';
                setTimeout(function() {
                    image.src = URL.createObjectURL(file)

                    image.style.removeProperty('opacity');
                    image.style.removeProperty('transition');
                }, 200);
            }
        });
    </script>
    <script src="https://cdn.ckeditor.com/4.19.0/full/ckeditor.js"></script>
    <script>
        CKEDITOR.config.language = 'fa';

        CKEDITOR.config.contentsCss = '<?php echo e(asset('admin/css/font/primary-iran-yekan.css')); ?>';
        CKEDITOR.config.font_names = 'primary-font';
        CKEDITOR.config.font_defaultLabel = 'primary-font';
        CKEDITOR.config.height = '300px';

        CKEDITOR.replace('text');
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/admin/posts/edit.blade.php ENDPATH**/ ?>