<?php $__env->startSection('title', 'کد تخفیف ها'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div>
                <div class="row align-items-end">
                    <div class="col-12">
                        <form class="d-flex justify-content-end">
                            <label for="search">جستجو:
                                <input type="search" id="search" class="form-control form-control-sm" name="search" value="<?php echo e(request('search') ?? ''); ?>">
                            </label>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <?php if(isset($discount)): ?>
                        <form action="<?php echo e(route('admin.discounts.update', $discount->id)); ?>" method="post" class="col-12 col-lg-5" enctype="multipart/form-data">
                            <?php echo method_field('PATCH'); ?>
                    <?php else: ?>
                        <form action="<?php echo e(route('admin.discounts.store')); ?>" method="post" class="col-12 col-lg-5" enctype="multipart/form-data">
                    <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-12">
                                <h6 class="card-title">ایجاد / تغییر کد تخفیف</h6>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="name">نام کد</label>
                                    <input name="name" id="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="نام کد تخفیف" type="text" <?php if(isset($discount)): ?> value="<?php echo e(old('name') ?? $discount->name); ?>" <?php endif; ?>>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="mb-4">
                                    <label for="expire_at">تاریخ انقضا</label>
                                    <input type="text" name="expire_at" class="form-control text-left <?php $__errorArgs = ['expire_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="تاریخ انقضا" dir="ltr" id="expire_at" <?php if(isset($discount)): ?> value="<?php echo e(old('expire_at') ?? jdate($discount->expire_at)->format('Y/m/d')); ?>" <?php endif; ?>>

                                    <?php $__errorArgs = ['expire_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="type">نوع</label>
                                    <select class="custom-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="type" name="type">
                                        <option value="percent" <?php if(old('type') ? old('type') == 'percent' : (isset($discount) ? $discount->type == 'percent' : '')): echo 'selected'; endif; ?>>درصد</option>
                                        <option value="static" <?php if(old('type') ? old('type') == 'static' : (isset($discount) ? $discount->type == 'static' : '')): echo 'selected'; endif; ?>>مقدار ثابت</option>
                                    </select>

                                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="value">مقدار</label>
                                    <input name="value" id="value" class="form-control <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="مقدار" type="text" <?php if(isset($discount)): ?> value="<?php echo e(old('value') ?? $discount->value); ?>" <?php endif; ?>>

                                    <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary btn-block">افزودن کد تخفیف</button>
                            </div>
                        </div>
                    </form>
                    <div class="col-12 col-lg-7 mt-5 table-responsive">
                        <table class="table table-striped table-bordered dtr-inline" role="grid" style="width: 100%;">
                            <thead>
                            <tr role="row">
                                <th>نام</th>
                                <th>مقدار</th>
                                <th>زمان ایجاد</th>
                                <th>تاریخ انقضا</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr role="row" class="<?php echo e($loop->odd ? 'odd' : 'even'); ?>">
                                    <td>
                                        <?php echo e($discount->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($discount->value); ?>

                                        <?php if($discount->type == 'static'): ?>
                                            تومان
                                        <?php elseif($discount->type == 'percent'): ?>
                                            درصد
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($discount->created_at()); ?>

                                    </td>
                                    <td>
                                        <?php echo e($discount->expire_at()); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.discounts.edit', $discount->id)); ?>">
                                            <button type="button" class="btn btn-warning btn-floating">
                                                <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                            </button>
                                        </a>
                                        <button class="btn btn-danger btn-floating" onclick="document.getElementById('delete-submit').value = <?php echo e($discount->id); ?>" data-toggle="modal" data-target="#delete">
                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr role="row">
                                    <td colspan="5">
                                        کد تخفیفی یافت نشد!
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo e($discounts->withQueryString()->links('vendor.pagination.admin', ['search' => request('search')])); ?>

            </div>
        </div>
    </div>

    <div class="modal fade" id="delete" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">حذف کد تخفیف</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="ti ti-close font-size-10"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <p>آیا از حذف کد تخفیف مطمئنید ؟</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary close-btn" data-dismiss="modal">لغو</button>
                    <form action="<?php echo e(route('admin.discounts.destroy')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" name="id" value="0" id="delete-submit" class="btn btn-danger">
                            <i class="fa fa-check m-r-5"></i>
                            حذف کد تخفیف
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-assets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/datepicker-jalali/bootstrap-datepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/datepicker/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
    <script src="<?php echo e(asset('admin/vendors/datepicker-jalali/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/datepicker-jalali/bootstrap-datepicker.fa.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/datepicker/daterangepicker.js')); ?>"></script>

    <script>
        $(document).ready(function () {
            $('#expire_at').datepicker({
                dateFormat: "yy/mm/dd",
                showOtherMonths: true,
                selectOtherMonths: true,
                minDate: 0,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/admin/discounts/index.blade.php ENDPATH**/ ?>