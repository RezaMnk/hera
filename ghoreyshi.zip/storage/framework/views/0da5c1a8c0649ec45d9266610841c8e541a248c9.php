<!DOCTYPE html>
<html lang="fa" dir="rtl">

<?php echo $__env->make('admin.layouts.sections.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

<!-- begin::page loader-->
<div class="page-loader">
    <div class="spinner-border"></div>
</div>
<!-- end::page loader -->

<?php echo $__env->make('admin.layouts.sections.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.sections.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- begin::main content -->
<main class="main-content">
    <?php echo $__env->yieldContent('content'); ?>
</main>
<!-- end::main content -->

<?php echo $__env->yieldContent('modal'); ?>

<?php echo $__env->make('admin.layouts.sections.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="colors">
    <!-- To use theme colors with Javascript -->
    <div class="bg-primary"></div>
    <div class="bg-primary-bright"></div>
    <div class="bg-secondary"></div>
    <div class="bg-secondary-bright"></div>
    <div class="bg-info"></div>
    <div class="bg-info-bright"></div>
    <div class="bg-success"></div>
    <div class="bg-success-bright"></div>
    <div class="bg-danger"></div>
    <div class="bg-danger-bright"></div>
    <div class="bg-warning"></div>
    <div class="bg-warning-bright"></div>
</div>

<!-- App scripts -->
<script src="<?php echo e(asset('admin/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

<?php echo $__env->yieldContent('footer-assets'); ?>

</body>

</html>
<?php /**PATH /home/rezamnk/ghoreyshi/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>