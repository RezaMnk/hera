<?php $__env->startSection('title', 'منو'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280 = $component; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['title' => 'منو','desc' => 'منو رستوران قریشی'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280)): ?>
<?php $component = $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280; ?>
<?php unset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- single product -->
    <div class="single-product mt-150 mb-150">
        <div class="container">
            <div class="row">
                <div class="col-8 offset-2 col-md-5 offset-md-0">
                    <div class="single-product-img">
                        <img src="<?php echo e($product->get_image()); ?>" alt="<?php echo e($product->name); ?>">
                    </div>
                </div>
                <div class="col-12 col-md-7">
                    <div class="single-product-content text-center text-md-left">
                        <h3>
                            <?php echo e($product->name); ?>

                        </h3>
                        <p>
                            <strong>دسته بندی:</strong>
                            <?php echo e($product->category->name); ?>

                        </p>
                        <p class="single-product-pricing">
                            <?php echo e(number_format($product->price)); ?> تومان
                        </p>
                        <p>
                            <strong>مشخصات:</strong>
                            <?php echo e($product->description); ?>

                        </p>
                        <?php if(auth()->guard()->check()): ?>
                            <div class="single-product-form">
                                <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="number" name="quantity" value="1" min="1">
                                    <button type="submit" class="product cart-btn icon-btn">
                                        افزودن به سبد
                                        <i class="fas fa-shopping-cart"></i>
                                    </button>
                                </form>
                            </div>
                        <?php endif; ?>
                        <h4>اشتراک گذاری:</h4>
                        <ul class="product-share">
                            <li><a href="https://t.me/share/url?url=<?php echo e(request()->url()); ?>" target="_blank"><i class="fab fa-telegram"></i></a></li>
                            <li><a href="https://api.whatsapp.com/send?text=<?php echo e(request()->url()); ?>" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
                            <li><a href="mailto:?subject=<?php echo e(env('app_name')); ?>&amp;body=<?php echo e(request()->url()); ?>" target="_blank"><i class="fa fa-envelope"></i></a></li>
                        </ul>
                        <?php if(auth()->guard()->guest()): ?>
                            <div class="mt-5">
                                <a href="http://127.0.0.1:8000/menu" class="boxed-btn icon-btn">
                                    برای سفارش وارد شوید
                                    <i class="fas fa-sign-in-alt"></i>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end single product -->

    <!-- more products -->
    <div class="more-products mb-150">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 text-center">
                    <div class="section-title">
                        <h3><span class="red-text">محصولات</span> مرتبط</h3>
                    </div>
                </div>
            </div>
            <div class="owl-carousel owl-theme">
                <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item text-center">
                        <div class="single-product-item">
                            <div class="product-image">
                                <a href="<?php echo e(route('home.product', $related_product->slug)); ?>">
                                    <img src="<?php echo e($related_product->get_image()); ?>" alt="<?php echo e($related_product->name); ?>">
                                </a>
                            </div>
                            <h3><?php echo e($related_product->name); ?></h3>
                            <p class="product-price">
                                <?php echo e(number_format($related_product->price)); ?> تومان
                            </p>
                            <?php if (isset($component)) { $__componentOriginal864988bfbff5494ec23537545356ff3b29d3faf9 = $component; } ?>
<?php $component = App\View\Components\AddToCart::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add-to-cart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AddToCart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal864988bfbff5494ec23537545356ff3b29d3faf9)): ?>
<?php $component = $__componentOriginal864988bfbff5494ec23537545356ff3b29d3faf9; ?>
<?php unset($__componentOriginal864988bfbff5494ec23537545356ff3b29d3faf9); ?>
<?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- end more products -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/home/product.blade.php ENDPATH**/ ?>