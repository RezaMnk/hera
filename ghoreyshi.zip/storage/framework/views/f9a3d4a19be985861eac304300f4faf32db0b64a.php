<div class="card sticky-cart">
    <div class="card-body">
        <div class="card-title border-bottom border-dark pb-2">
            <h5 class="d-inline">سبد خرید</h5>
            <form class="d-inline" action="<?php echo e(route('cart.clear')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button class="bordered-primary-btn clear-cart-button" type="submit">
                    حذف
                </button>
            </form>
        </div>
        <div class="cart-products">
            <?php $__empty_1 = true; $__currentLoopData = cart()->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="row my-3">
                    <div class="col-8">
                        <a href="<?php echo e(route('home.product', $cart_item['product']->slug)); ?>">
                            <?php echo e($cart_item['product']->name); ?>

                        </a>
                        <p class="cart-product-price">
                            قیمت واحد: <?php echo e(number_format($cart_item['product']->price)); ?> تومان
                        </p>
                    </div>
                    <div class="col-4 cart-count-box" data-slug="<?php echo e($cart_item['product']->slug); ?>">
                        <div class="cart-count-loading"></div>
                        <i class="fa fa-plus cart-add-count" data-id="add"></i>
                        <span class="cart-count"><?php echo e($cart_item['quantity']); ?></span>
                        <i class="fa fa-minus cart-remove-count" data-id="remove"></i>
                    </div>
                </div>
                <?php if (! ($loop->last)): ?>
                    <hr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="my-3">
                    سبد خرید خالی می باشد!
                </p>
            <?php endif; ?>
        </div>
        <div class="cart-buttons">
            <a href="<?php echo e(route('home.cart')); ?>" class="boxed-btn w-100 text-center">ثبت سفارش</a>
        </div>
    </div>
</div>
<?php /**PATH /home/rezamnk/ghoreyshi/resources/views/components/sticky-cart.blade.php ENDPATH**/ ?>