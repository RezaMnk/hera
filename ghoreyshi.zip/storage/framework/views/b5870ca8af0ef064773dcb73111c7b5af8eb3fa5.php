<!DOCTYPE html>
<html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="رستوران قریشی - خرید آنلاین، تحویل فوری">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- title -->
        <title><?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?></title>

        <!-- favicon -->
        <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.png')); ?>">

        <!-- fontawesome -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>">
        <!-- owl carousel -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.css')); ?>">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>">
        <!-- animate css -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
        <!-- mean menu css -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu.min.css')); ?>">
        <!-- main style -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
        <!-- responsive -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">

        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

        <?php echo $__env->yieldContent('styles'); ?>
    </head>
    <body>

        <?php echo $__env->make('home.layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('breadcrumb'); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php if (! (request()->routeIs('home.home'))): ?>
            <?php echo $__env->make('home.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <!-- jquery -->
        <script src="<?php echo e(asset('assets/js/jquery-1.11.3.min.js')); ?>"></script>
        <!-- bootstrap -->
        <script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
        <!-- count down -->
        <script src="<?php echo e(asset('assets/js/jquery.countdown.js')); ?>"></script>
        <!-- isotope -->
        <script src="<?php echo e(asset('assets/js/jquery.isotope-3.0.6.min.js')); ?>"></script>
        <!-- waypoints -->
        <script src="<?php echo e(asset('assets/js/waypoints.js')); ?>"></script>
        <!-- owl carousel -->
        <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
        <!-- magnific popup -->
        <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
        <!-- mean menu -->
        <script src="<?php echo e(asset('assets/js/jquery.meanmenu.min.js')); ?>"></script>
        <!-- sticker js -->
        <script src="<?php echo e(asset('assets/js/sticker.js')); ?>"></script>
        <!-- main js -->
        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
        <!-- cart counter js -->
        <script src="<?php echo e(asset('assets/js/cart-counter.js')); ?>"></script>


        <script>
            addEventListener('DOMContentLoaded', (event) => {
                <?php if(Session::has('toast.success')): ?>
                window.Toastify({
                    text: "<?php echo e(session('toast.success')); ?>",
                    position: "left",
                    duration: 3000,
                    className: "toastify-success",
                    offset: {
                        x: '2rem',
                        y: '2rem'
                    }
                }).showToast();

                <?php elseif(Session::has('toast.danger')): ?>
                Toastify({
                    text: "<?php echo e(session('toast.danger')); ?>",
                    position: "left",
                    className: "toastify-danger",
                    offset: {
                        x: '2rem',
                        y: '2rem'
                    }
                }).showToast();

                <?php elseif(Session::has('toast.info')): ?>
                Toastify({
                    text: "<?php echo e(session('toast.info')); ?>",
                    position: "left",
                    className: "toastify-info",
                    offset: {
                        x: '2rem',
                        y: '2rem'
                    }
                }).showToast();

                <?php elseif(Session::has('toast.warning')): ?>
                Toastify({
                    text: "<?php echo e(session('toast.warning')); ?>",
                    position: "left",
                    className: "toastify-warning",
                    offset: {
                        x: '2rem',
                        y: '2rem'
                    }
                }).showToast();

                <?php endif; ?>
            });
        </script>

        <?php echo $__env->yieldPushContent('scripts'); ?>

    </body>
</html>
<?php /**PATH /home/rezamnk/ghoreyshi/resources/views/home/layouts/app.blade.php ENDPATH**/ ?>