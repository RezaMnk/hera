<?php $__env->startSection('title', 'صورت حساب'); ?>

<?php $__env->startSection('header-assets'); ?>
    <link href="https://unpkg.com/dropzone@6.0.0-beta.1/dist/dropzone.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card" id="section-to-print">

        <div class="card-body p-md-50">
            <div class="invoice">
                <div class="row">
                    <h2 class="col-6 offset-3 col-md-2 offset-md-0">
                        <a href="<?php echo e(route('home.home')); ?>">
                            <img class="m-r-20 w-100" src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="image">
                        </a>
                    </h2>
                    <div class="col-12 col-md-10 justify-content-center justify-content-md-end d-flex align-items-center">
                        <h3 class="text-xs-left mb-0">صورتحساب #<?php echo e($order->id); ?></h3>
                    </div>

                </div>
                <hr class="my-4">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <p class="text-center text-md-left">
                            <b>کاربر</b>
                        </p>
                        <p class="text-center text-md-left mb-1">
                            <b>نام: </b> <?php echo e($order->user->name); ?>

                        </p>
                        <p class="text-center text-md-left">
                            <b>شماره تماس: </b> <?php echo e($order->user->phone); ?>

                        </p>
                    </div>
                    <div class="col-12 col-md-6">
                        <p class="text-center text-md-right">
                            <b>صورتحساب به</b>
                        </p>
                        <p class="text-center text-md-right">
                            استان تهران <br>
                            شهر تهران <br>
                            آدرس: <?php echo e($order->map->address()); ?>

                        </p>
                    </div>
                </div>
                <hr class="d-md-none">

                <div class="table-responsive">
                    <div class="d-block d-md-none">
                        <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-5 align-self-center">
                                <img src="<?php echo e($product->get_image()); ?>" class="w-100" alt="product">
                            </div>
                            <div class="col-7">
                                <h5><?php echo e($product->name); ?></h5>
                                 <p><?php echo e(number_format($product->price)); ?> × <?php echo e($product->pivot->quantity); ?> = <?php echo e(number_format($product->price * $product->pivot->quantity)); ?> تومان</p>
                            </div>
                        </div>
                        <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <table class="table m-t-b-50 d-md-table d-none">
                        <thead>
                        <tr class="bg-dark text-white print-text-black">
                            <th>#</th>
                            <th>تصویر محصول</th>
                            <th>نام محصول</th>
                            <th>قیمت (تومان)</th>
                            <th>تعداد</th>
                            <th>کل (تومان)</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php ($total = 0); ?>
                        <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($total += $product->price * $product->pivot->quantity); ?>
                            <tr class="text-right">
                                <td class="text-left">
                                    <?php echo e($loop->iteration); ?>

                                </td>
                                <td class="text-left">
                                    <img src="<?php echo e($product->get_image()); ?>" width="50px">
                                </td>
                                <td class="text-left">
                                    <?php echo e($product->name); ?>

                                </td>
                                <td class="text-left">
                                    <?php echo e(number_format($product->price)); ?>

                                </td>
                                <td class="text-left">
                                    <p class="m-0"><?php echo e($product->pivot->quantity); ?> عدد</p>
                                </td>
                                <td class="text-left">
                                    <?php echo e(number_format($product->price * $product->pivot->quantity)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <p class="text-center small text-muted m-t-50">
                    <span class="row">
                        <span class="col-md-6 offset-md-3">
                            رستوران قریشی، اولین تهیه غذای آنلاین ایرانی
                        </span>
                    </span>
                </p>
            </div>
            <div class="text-right d-print-none">
                <hr class="my-5">
                <a href="javascript:window.print()" class="btn btn-light m-l-5 my-1">
                    <i class="fa fa-print m-r-5"></i> چاپ
                </a>
                <a href="<?php echo e(route('home.home')); ?>" class="btn btn-danger m-l-5 my-1">
                    <i class="fa fa-home m-r-5"></i>
                    بازگشت به سایت
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.sections.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('home.layouts.invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/home/invoice.blade.php ENDPATH**/ ?>