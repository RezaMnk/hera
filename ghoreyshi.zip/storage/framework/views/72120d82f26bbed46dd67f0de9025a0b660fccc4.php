<!DOCTYPE html>
<html lang="fa" dir="rtl">

<?php echo $__env->make('admin.layouts.sections.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body dir="rtl">

    <main class="main-content ml-0">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->yieldContent('modal'); ?>

    <?php echo $__env->make('admin.layouts.sections.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

<script src="<?php echo e(asset('admin/js/app.js')); ?>"></script>

<?php echo $__env->yieldContent('footer-assets'); ?>
</html>
<?php /**PATH /home/rezamnk/ghoreyshi/resources/views/home/layouts/invoice.blade.php ENDPATH**/ ?>