<?php $__env->startSection('title', 'ورود'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280 = $component; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['title' => 'ورود','desc' => 'فرم ورود به حساب کاربری'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280)): ?>
<?php $component = $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280; ?>
<?php unset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-8 offset-2">
                <div id="map" class="w-100" style="height: 50vh"></div>
                <form>
                    <input type="hidden" name="lat" id="lat">
                    <input type="hidden" name="long" id="long">
                    <button type="submit">Submit</button>
                </form>
            </div>
        </div>
    </div>

    <?php echo $__env->make('home.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <link href="https://static.neshan.org/sdk/leaflet/1.4.0/leaflet.css" rel="stylesheet" type="text/css">
    <script src="https://static.neshan.org/sdk/leaflet/1.4.0/leaflet.js" type="text/javascript"></script>

    <script type="text/javascript">

        <?php
            $text = 'میدان شهدا';

            $coordinates = \App\Models\Map::search($text);
        ?>

        let lat = <?php echo e($coordinates['lat']); ?>;
        let lon = <?php echo e($coordinates['long']); ?>;

        let icon = L.icon({
            iconUrl: '<?php echo e(asset('assets/icons/leaflet/location.svg')); ?>',
            iconSize:     [38, 100], // size of the icon
            iconAnchor:   [18, 67], // point of the icon which will correspond to marker's location
        });

        let map = new L.Map('map', {
            key: 'web.a26d783d73c94bec9900322ce1a88f99',
            maptype: 'dreamy',
            poi: true,
            traffic: false,
            center: [35.6913604736328, 51.4785614013672],
            zoom: 14,
        });
        var marker = L.marker([lat, lon], {icon: icon}).addTo(map);
        map.on('click', function(e) {
            if(marker)
                map.removeLayer(marker);
            document.getElementById('lat').value = e.latlng.lat;
            document.getElementById('long').value = e.latlng.lng;
            marker = L.marker([e.latlng], {icon: icon}).addTo(map);
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/home/map.blade.php ENDPATH**/ ?>