<!-- Plugin scripts -->
<script src="<?php echo e(asset('admin/vendors/bundle.js')); ?>"></script>

<!-- Chartjs -->
<script src="<?php echo e(asset('admin/vendors/charts/chartjs/chart.min.js')); ?>"></script>

<!-- Circle progress -->
<script src="<?php echo e(asset('admin/vendors/circle-progress/circle-progress.min.js')); ?>"></script>

<!-- Peity -->
<script src="<?php echo e(asset('admin/vendors/charts/peity/jquery.peity.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/examples/charts/peity.js')); ?>"></script>

<!-- Datepicker -->
<script src="<?php echo e(asset('admin/vendors/datepicker/daterangepicker.js')); ?>"></script>

<!-- Slick -->
<script src="<?php echo e(asset('admin/vendors/slick/slick.min.js')); ?>"></script>

<!-- Vamp -->
<script src="<?php echo e(asset('admin/vendors/vmap/jquery.vmap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendors/vmap/maps/jquery.vmap.usa.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/examples/vmap.js')); ?>"></script>

<!-- Dashboard scripts -->
<script src="<?php echo e(asset('admin/js/examples/dashboard.js')); ?>"></script>

<script>
    toastr.options = {
        timeOut: 10000,
        progressBar: true,
        showMethod: "slideDown",
        hideMethod: "slideUp",
        showDuration: 200,
        hideDuration: 200
    };

    <?php if(Session::has('toast.success')): ?>
        toastr.success("<?php echo e(session('toast.success')); ?>");

    <?php elseif(Session::has('toast.danger')): ?>
        toastr.error("<?php echo e(session('toast.danger')); ?>");

    <?php elseif(Session::has('toast.info')): ?>
        toastr.info("<?php echo e(session('toast.info')); ?>");

    <?php elseif(Session::has('toast.warning')): ?>
        toastr.warning("<?php echo e(session('toast.warning')); ?>");

    <?php endif; ?>
</script>
<?php /**PATH /home/rezamnk/ghoreyshi/resources/views/admin/layouts/sections/footer-scripts.blade.php ENDPATH**/ ?>