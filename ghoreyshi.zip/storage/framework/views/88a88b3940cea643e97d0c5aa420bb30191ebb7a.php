<?php if(auth()->guard()->check()): ?>
    <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button type="submit" class="cart-btn icon-btn">
                افزودن به سبد
            <i class="fas fa-shopping-cart"></i>
        </button>
        <button type="submit" class="d-block d-md-none cart-btn mobile-add-to-cart">
            <i class="fa fa-plus"></i>
        </button>
    </form>
<?php endif; ?>
<?php /**PATH /home/rezamnk/ghoreyshi/resources/views/components/add-to-cart.blade.php ENDPATH**/ ?>