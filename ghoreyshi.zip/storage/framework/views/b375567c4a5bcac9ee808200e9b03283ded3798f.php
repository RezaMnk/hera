<?php $__env->startSection('title', 'کاربران'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4">
                <div class="row align-items-end">
                    <div class="col-12">
                        <form class="d-flex justify-content-end">

                            <label for="search">جستجو:
                                <input type="search" id="search" class="form-control form-control-sm" name="search" value="<?php echo e(request('search') ?? ''); ?>">
                            </label>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 table-responsive">
                        <table class="table table-striped table-bordered dtr-inline" role="grid" style="width: 100%;">
                            <thead>
                            <tr role="row">
                                <th>شناسه</th>
                                <th>نام</th>
                                <th>شماره تلفن</th>
                                <th>زمان ایجاد</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr role="row" class="<?php echo e($loop->odd ? 'odd' : 'even'); ?>">
                                    <td>
                                        <?php echo e($user->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($user->name); ?>

                                    </td>
                                    <td class="ls-1">
                                        <?php echo e($user->phone); ?>

                                    </td>
                                    <td>
                                        <?php echo e($user->created_at()); ?>

                                    </td>
                                    <td>
                                        <?php if(auth()->user()->is_owner()): ?>
                                            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-warning btn-floating">
                                                <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                            </a>
                                            <button class="btn btn-danger btn-floating" onclick="document.getElementById('delete-submit').value = <?php echo e($user->id); ?>" data-toggle="modal" data-target="#delete">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr role="row">
                                    <td colspan="5">
                                        کاربری یافت نشد!
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo e($users->appends(['search' => request('search')])->links()); ?>

            </div>
        </div>
    </div>

    <div class="modal fade" id="delete" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">حذف کاربر</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="ti ti-close font-size-10"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <p>آیا از حذف کاربر مطمئنید ؟</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary close-btn" data-dismiss="modal">لغو</button>
                    <form action="<?php echo e(route('admin.users.destroy')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" name="id" value="0" id="delete-submit" class="btn btn-danger">
                            <i class="fa fa-check m-r-5"></i>
                            حذف کاربر
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/admin/users/index.blade.php ENDPATH**/ ?>