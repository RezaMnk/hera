<!--PreLoader-->
<div class="loader">
    <div class="loader-inner">
        <div class="circle"></div>
    </div>
</div>
<!--PreLoader Ends-->

<!-- header -->
<div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['top-header-area', 'home-header' => request()->routeIs('home.home')]) ?>" id="sticker">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-sm-12 text-center">
                <div class="main-menu-wrap">
                    <!-- logo -->
                    <div class="site-logo d-none d-lg-block">
                        <a href="<?php echo e(route('home.home')); ?>">
                            <img src="<?php echo e(asset('assets/img/logo-w.png')); ?>" alt="">
                        </a>
                    </div>
                    <div class="d-block d-lg-none">
                        <a href="<?php echo e(route('home.home')); ?>">
                            <img src="<?php echo e(asset('assets/img/logo-w.png')); ?>" alt="">
                        </a>
                    </div>
                    <!-- logo -->

                    <!-- menu start -->
                    <nav class="main-menu">
                        <ul>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['current-list-item' => request()->routeIs('home.home')]) ?>">
                                <a href="<?php echo e(route('home.home')); ?>">صفحه اصلی</a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['current-list-item' => request()->routeIs('home.menu')]) ?>">
                                <a href="<?php echo e(route('home.menu')); ?>">سفارش آنلاین</a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['current-list-item' => request()->routeIs('home.company')]) ?>">
                                <a href="<?php echo e(route('home.company')); ?>">غذای شرکتی</a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['current-list-item' => request()->routeIs('home.posts')]) ?>">
                                <a href="<?php echo e(route('home.posts')); ?>">وبلاگ</a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['current-list-item' => request()->routeIs('home.about')]) ?>">
                                <a href="<?php echo e(route('home.about')); ?>">درباره ما</a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['current-list-item' => request()->routeIs('home.contact')]) ?>">
                                <a href="<?php echo e(route('home.contact')); ?>">تماس با ما</a>
                            </li>
                            <li>
                                <div class="header-icons">
                                    <?php if(auth()->guard()->check()): ?>
                                        <a href="<?php echo e(route('home.profile')); ?>">
                                            <i class="fas fa-user"></i>
                                        </a>
                                        <a class="shopping-cart" href="<?php echo e(route('home.cart')); ?>">
                                            <i class="fas fa-shopping-cart"></i>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('login')); ?>">
                                            <i class="fas fa-sign-in-alt"></i>
                                        </a>
                                    <?php endif; ?>
                                    <a class="mobile-hide search-bar-icon" href="javascript: void(0)">
                                        <i class="fas fa-search"></i>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </nav>
                    <!-- menu end -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end header -->

<!-- mobile menu -->
<div class="mobile-static-menu d-block d-lg-none">
    <ul>
        <li>
            <a class="mobile-menu" href="javascript:void(0)">
                <i class="fas fa-list"></i>
                منو
            </a>
        </li>
        <?php if(auth()->guard()->check()): ?>
            <li>
                <a class="mobile-cart" href="javascript:void(0)">
                    <i class="fas fa-shopping-cart"></i>
                    سبد خرید
                    <?php if(($count = cart()->all()->count()) > 0): ?>
                        (<?php echo e($count); ?>)
                    <?php endif; ?>
                </a>
            </li>
            <li>
                <a class="search-bar-icon" href="javascript:void(0)">
                    <i class="fas fa-search"></i>
                    جست و جو
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('home.profile')); ?>">
                    <i class="fas fa-user"></i>
                    پروفایل
                </a>
            </li>
        <?php else: ?>
            <li>
                <a class="search-bar-icon" href="javascript:void(0)">
                    <i class="fas fa-search"></i>
                    جست و جو
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('login')); ?>">
                    <i class="fas fa-sign-in-alt"></i>
                    ورود به حساب
                </a>
            </li>
        <?php endif; ?>
    </ul>
</div>
<!-- end mobile menu -->


<!-- search area -->
<div class="search-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <span class="close-btn search-close">
                    <i class="fas fa-window-close"></i>
                </span>
                <form action="<?php echo e(route('home.menu')); ?>" class="search-bar">
                    <div class="search-bar-tablecell">
                        <h3>جست و جو:</h3>
                        <input type="text" name="search" placeholder="نام غذا" <?php if(request()->has('search')): ?> value="<?php echo e(request('search')); ?>" <?php endif; ?>>
                        <button type="submit">
                            جست و جو
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end search area -->


<!-- mobile menu area -->
<div class="mobile-menu-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <span class="close-btn mobile-menu-close">
                    <i class="fas fa-window-close"></i>
                </span>
                <div class="menu-list">
                    <div class="menu-list-tablecell">
                        <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home.home')]) ?>">
                            <a href="<?php echo e(route('home.home')); ?>">صفحه اصلی</a>
                        </h4>
                        <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home.menu')]) ?>">
                            <a href="<?php echo e(route('home.menu')); ?>">سفارش آنلاین</a>
                        </h4>
                        <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home.company')]) ?>">
                            <a href="<?php echo e(route('home.company')); ?>">غذای شرکتی</a>
                        </h4>
                        <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home.posts')]) ?>">
                            <a href="<?php echo e(route('home.posts')); ?>">وبلاگ</a>
                        </h4>
                        <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home.about')]) ?>">
                            <a href="<?php echo e(route('home.about')); ?>">درباره ما</a>
                        </h4>
                        <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home.contact')]) ?>">
                            <a href="<?php echo e(route('home.contact')); ?>">تماس با ما</a>
                        </h4>
                        <?php if(auth()->guard()->check()): ?>
                            <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home.cart')]) ?>">
                                <a href="<?php echo e(route('home.cart')); ?>">سبد خرید</a>
                            </h4>
                            <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home.profile')]) ?>">
                                <a href="<?php echo e(route('home.profile')); ?>">پروفایل</a>
                            </h4>
                            <hr>
                            <h4>
                                <form action="<?php echo e(route('logout')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <a href="javascript:void(0)">
                                        <button type="submit" class="btn btn-default">
                                            خروج از حساب
                                        </button>
                                    </a>
                                </form>
                            </h4>
                        <?php else: ?>
                            <hr>
                            <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('login')]) ?>">
                                <a href="<?php echo e(route('login')); ?>">ورود به حساب</a>
                            </h4>
                            <h4 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('register')]) ?>">
                                <a href="<?php echo e(route('register')); ?>">ثبت نام</a>
                            </h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end mobile menu area -->

<?php if(auth()->guard()->check()): ?>
    <!-- mobile cart area -->
    <div class="mobile-cart-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <span class="close-btn mobile-cart-close">
                        <i class="fas fa-window-close"></i>
                    </span>
                    <div class="cart-list">
                        <div class="cart-list-tablecell">
                            <?php $__empty_1 = true; $__currentLoopData = cart()->all()->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="row my-3 cart-item">
                                    <div class="col-2">
                                        <img src="<?php echo e($cart_item['product']->get_image()); ?>" alt="<?php echo e($cart_item['product']->name); ?>">
                                    </div>
                                    <div class="col-6 text-left">
                                        <a href="<?php echo e(route('home.product', $cart_item['product']->slug)); ?>">
                                            <?php echo e($cart_item['product']->name); ?>

                                        </a>
                                        <p class="cart-product-price">
                                            قیمت واحد: <?php echo e(number_format($cart_item['product']->price)); ?> تومان
                                        </p>
                                    </div>
                                    <div class="col-4 cart-count-box" data-slug="<?php echo e($cart_item['product']->slug); ?>">
                                        <div class="cart-count-loading"></div>
                                        <i class="fa fa-plus cart-add-count" data-id="add"></i>
                                        <span class="cart-count"><?php echo e($cart_item['quantity']); ?></span>
                                        <i class="fa fa-minus cart-remove-count" data-id="remove"></i>
                                    </div>
                                </div>
                                <?php if (! ($loop->last)): ?>
                                    <hr>
                                <?php endif; ?>
                                <?php if($loop->last): ?>
                                    <?php if(cart()->all()->count() > 4): ?>
                                        <div class="row my-4">
                                            <div class="col-12 text-left">
                                                <p class="more-products">
                                                    + <?php echo e(cart()->all()->count() - 4); ?> محصول بیشتر
                                                </p>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="row cart-actions">
                                        <div class="col-3">
                                            <form class="d-inline" action="<?php echo e(route('cart.clear')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <button class="bordered-primary-btn btn-small clear-cart-button w-100 text-center" type="submit">
                                                    حذف
                                                </button>
                                            </form>
                                        </div>
                                        <div class="col-9">
                                            <a class="boxed-btn btn-small show-cart-page w-100 text-center" href="<?php echo e(route('home.cart')); ?>">
                                                مشاهده سبد خرید
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="empty-cart">
                                    سبد خرید خالی می باشد!
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end mobile menu area -->
<?php endif; ?>
<?php /**PATH /home/rezamnk/ghoreyshi/resources/views/home/layouts/partials/header.blade.php ENDPATH**/ ?>