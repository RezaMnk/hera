<?php $__env->startSection('title', 'تایید حساب'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280 = $component; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['title' => 'تایید حساب','desc' => 'کد تایید دو مرحله ای'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280)): ?>
<?php $component = $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280; ?>
<?php unset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-6">
                <div class="auth-form">
                    <form method="POST" action="<?php echo e(route('2fa.index')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-5">
                            <div class="col-12">
                                <label for="code">کد تایید دو مرحله ای</label>
                                <input type="text" placeholder="کد تایید" name="code" id="code" pattern="[0-9]{4}" required <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> class="is-invalid" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> autocomplete="code" autofocus>

                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-8">
                                <input type="submit" value="تایید کد">
                            </div>
                            <div class="col-4 text-right">
                                <div class="row" id="countdown-container">
                                    <p class="col-8">
                                        ارسال مجدد تا
                                    </p>
                                    <span class="col-4" id="countdown">02:00</span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-6 welcome-image" style="background-image: url('<?php echo e(asset('assets/img/welcome.jpg')); ?>')"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.onload = function () {

            let container = document.querySelector('#countdown-container');
            let display = document.querySelector('#countdown');
            let duration = '120';

            let timer = duration, minutes, seconds;
            let countdownInterval = setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                display.textContent = minutes + ":" + seconds;

                if (--timer < 0) {
                    clearInterval(countdownInterval);
                    container.style.transition = "opacity .2s ease";

                    container.style.opacity = '0';
                    setTimeout(function() {
                        container.innerHTML = `
                        <a class="resend col-12" href="<?php echo e(route('2fa.resend')); ?>">
                            ارسال مجدد
                        </a>
                        `
                        container.style.removeProperty('opacity');
                        container.style.removeProperty('transition');
                    }, 200);
                }
            }, 1000);
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('home.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/auth/verify.blade.php ENDPATH**/ ?>