<?php $__env->startSection('title', 'محصولات'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div>
                <div class="row align-items-end">
                    <div class="col-6">
                        <a class="btn btn-primary mb-2" href="<?php echo e(route('admin.products.create')); ?>">افزودن</a>
                    </div>
                    <div class="col-6">
                        <form class="d-flex justify-content-end">

                            <label for="search">جستجو:
                                <input type="search" id="search" class="form-control form-control-sm" name="search" value="<?php echo e(request('search') ?? ''); ?>">
                            </label>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 table-responsive">
                        <table class="table table-striped table-bordered dtr-inline" role="grid" style="width: 100%;">
                            <thead>
                            <tr role="row">
                                <th>کد</th>
                                <th>نام</th>
                                <th>قیمت</th>
                                <th>زمان ایجاد</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr role="row" class="<?php echo e($loop->odd ? 'odd' : 'even'); ?>">
                                    <td>
                                        <?php echo e($product->id); ?>

                                    </td>
                                    <td>
                                        <img src="<?php echo e($product->get_image()); ?>" alt="<?php echo e($product->name); ?>" class="mr-2" width="50px">
                                        <span>
                                            <?php echo e($product->name); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php echo e(number_format($product->price)); ?> تومان
                                    </td>
                                    <td>
                                        <?php echo e($product->created_at()); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>">
                                            <button type="button" class="btn btn-warning btn-floating">
                                                <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                            </button>
                                        </a>
                                        <a href="<?php echo e(route('home.product', $product->slug)); ?>">
                                            <button type="button" class="btn btn-success btn-floating">
                                                <i class="fa fa-eye" aria-hidden="true"></i>
                                            </button>
                                        </a>
                                        <button class="btn btn-danger btn-floating" onclick="document.getElementById('delete-submit').value = <?php echo e($product->id); ?>" data-toggle="modal" data-target="#delete">
                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr role="row">
                                    <td colspan="5">
                                        محصولی یافت نشد!
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo e($products->withQueryString()->links('vendor.pagination.admin', ['search' => request('search')])); ?>

            </div>
        </div>
    </div>

    <div class="modal fade" id="delete" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">حذف محصول</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="ti ti-close font-size-10"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <p>آیا از حذف محصول مطمئنید ؟</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary close-btn" data-dismiss="modal">لغو</button>
                    <form action="<?php echo e(route('admin.products.destroy')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" name="id" value="0" id="delete-submit" class="btn btn-danger">
                            <i class="fa fa-check m-r-5"></i>
                            حذف محصول
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/admin/products/index.blade.php ENDPATH**/ ?>