<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo e(config('app.name', 'Laravel')); ?> | <?php echo $__env->yieldContent('title'); ?></title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>">

    <!-- Theme Color -->
    <meta name="theme-color" content="#5867dd">

    <!-- Plugin styles -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/bundle.css')); ?>" type="text/css">











    <!-- App styles -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/app.css')); ?>" type="text/css">

    <!-- Layout header assets -->
    <?php echo $__env->yieldContent('header-assets'); ?>
</head>
<?php /**PATH /home/rezamnk/ghoreyshi/resources/views/admin/layouts/sections/head.blade.php ENDPATH**/ ?>