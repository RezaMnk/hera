<?php $__env->startSection('title', 'ایجاد محصول'); ?>

<?php $__env->startSection('content'); ?>
    <!-- row : start  -->
    <form action="<?php echo e(route('admin.products.store')); ?>" method="post" class="row" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- right col start -->
        <div class="col-12 col-md-9">

            <div class="card d-block d-md-none">
                <div class="card-body row">
                    <div class="col-8">
                        <button type="submit" name="status" value="1" class="btn btn-success btn-block">انتشار</button>
                    </div>
                    <div class="col-4">
                        <a href="<?php echo e(route('admin.products.index')); ?>">
                            <button type="button" class="btn btn-danger btn-block">لغو</button>
                        </a>
                    </div>
                </div>
            </div>

            <!-- title card : start  -->
            <div class="card">
                <div class="card-body row">
                    <div class="col-12 col-md-8">
                        <label for="name">نام محصول</label>
                        <input type="text" id="name" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="نام محصول" value="<?php echo e(old('name')); ?>" required>

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 col-md-4">
                        <label for="price">قیمت</label>
                        <input type="number" id="price" name="price" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="قیمت محصول" value="<?php echo e(old('price')); ?>" required>

                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <!-- title card : end  -->

            <!-- description card : start  -->
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">توضیحات محصول</h6>
                    <textarea id="description" name="description" rows="4" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description')); ?></textarea>

                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- description card : end  -->

            <!-- category card : start  -->
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">دسته بندی</h6>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label class="image-radio">
                            <input type="radio" name="category" value="<?php echo e($category->id); ?>" <?php if(old('category') == $category->id): echo 'checked'; endif; ?> />
                            <img src="<?php echo e($category->get_image()); ?>" alt="<?php echo e($category->name); ?>">
                            <span>
                                <?php echo e($category->name); ?>

                            </span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        ابتدا از بخش <a href="<?php echo e(route('admin.categories.index')); ?>" class="text-primary">دسته بندی ها</a>، یک دسته بندی ایجاد کنید.
                    <?php endif; ?>

                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- category card : end  -->
        </div>
        <!-- right col end -->

        <!-- left col start -->
        <div class="col-12 col-md-3">
            <!-- detail card : start  -->
            <div class="card d-none d-md-block">
                <div class="card-body row">
                    <div class="col-8">
                        <button type="submit" name="status" value="1" class="btn btn-success btn-block">انتشار</button>
                    </div>
                    <div class="col-4">
                        <a href="<?php echo e(route('admin.products.index')); ?>">
                            <button type="button" class="btn btn-danger btn-block">لغو</button>
                        </a>
                    </div>
                </div>
            </div>
            <!-- detail card : end  -->
            <!-- image card : start -->
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">تصویر محصول</h6>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image" id="product-image-input" accept="image/*">
                        <label class="custom-file-label" for="product-image-input">انتخاب فایل تصویر</label>
                    </div>
                    <div class="mt-4">
                        <img src="<?php echo e(asset('storage/default.png')); ?>" id="product-image" class="w-100 shadow-sm rounded" alt="تصویر محصول">
                    </div>

                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- image card : end -->
        </div>
        <!-- left col : end -->
    </form>
    <!-- row : end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-assets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/file-manager/css/file-manager.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
    <script>
        let image_input = document.querySelector('#product-image-input');
        let image = document.querySelector('#product-image');

        image_input.addEventListener('change', function (elem) {
            const [file] = image_input.files
            if (file) {
                image.style.transition = "opacity .1s ease";

                image.style.opacity = '0';
                setTimeout(function() {
                    image.src = URL.createObjectURL(file)

                    image.style.removeProperty('opacity');
                    image.style.removeProperty('transition');
                }, 200);
            }
        });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/admin/products/create.blade.php ENDPATH**/ ?>