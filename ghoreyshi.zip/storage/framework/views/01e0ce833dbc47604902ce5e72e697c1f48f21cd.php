<?php $__env->startSection('title', 'سبد خرید'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280 = $component; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['title' => 'سبد خرید','desc' => 'محصولاتی که به سبد خریدتان افزودید'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280)): ?>
<?php $component = $__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280; ?>
<?php unset($__componentOriginal40fe594eae3d7d27fa8bd9a508c1498f43cae280); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- cart -->
    <div class="cart-section mt-150 mb-150">
        <div class="container">
            <div class="row">
                <div class="col-12 d-block d-md-none">
                    <?php $__empty_1 = true; $__currentLoopData = cart()->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="cart-item-mobile row">
                            <div class="col-2 mobile-product-image">
                                <a href="<?php echo e(route('home.product', $cart_item['product']->slug)); ?>">
                                    <img src="<?php echo e($cart_item['product']->get_image()); ?>" alt="<?php echo e($cart_item['product']->name); ?>">
                                </a>
                            </div>
                            <div class="col-4 mobile-product-name">
                                <a href="<?php echo e(route('home.product', $cart_item['product']->slug)); ?>">
                                    <?php echo e($cart_item['product']->name); ?>

                                </a>
                                <span><?php echo e(number_format($cart_item['product']->price)); ?> تومان</span>
                            </div>
                            <div class="col-4">
                                <div class="cart-count-box" data-slug="<?php echo e($cart_item['product']->slug); ?>">
                                    <div class="cart-count-loading"></div>
                                    <i class="fa fa-plus cart-add-count" data-id="add"></i>
                                    <span class="cart-count"><?php echo e($cart_item['quantity']); ?></span>
                                    <i class="fa fa-minus cart-remove-count" data-id="remove"></i>
                                </div>
                            </div>
                            <div class="col-2 text-right">
                                <form action="<?php echo e(route('cart.remove', $cart_item['product']->id)); ?>" method="post" class="mobile-product-remove">
                                    <?php echo csrf_field(); ?>

                                    <button type="submit" class="boxed-btn btn-small">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                        <?php if (! ($loop->last)): ?>
                            <hr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="ml-5">
                            سبد خرید خالی می باشد!
                        </p>
                    <?php endif; ?>
                </div>
                <div class="col-lg-8 col-12 d-none d-md-block">
                    <div class="cart-table-wrap">
                        <table class="cart-table">
                            <thead class="cart-table-head">
                            <tr class="table-head-row">
                                <th class="product-remove"></th>
                                <th class="product-image">تصویر</th>
                                <th class="product-name">نام</th>
                                <th class="product-price">قیمت (تومان)</th>
                                <th class="product-quantity">تعداد</th>
                                <th class="product-total">جمع (تومان)</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php ($total = 0); ?>
                                <?php $__empty_1 = true; $__currentLoopData = cart()->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php ($total += $cart_item['product']->price * $cart_item['quantity']); ?>
                                    <tr class="table-body-row" data-slug="<?php echo e($cart_item['product']->slug); ?>">
                                        <td class="product-remove">
                                            <form action="<?php echo e(route('cart.remove', $cart_item['product']->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>

                                                <button type="submit">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </form>
                                        </td>
                                        <td class="product-image">
                                            <a href="<?php echo e(route('home.product', $cart_item['product']->slug)); ?>">
                                                <img src="<?php echo e($cart_item['product']->get_image()); ?>" alt="<?php echo e($cart_item['product']->name); ?>">
                                            </a>
                                        </td>
                                        <td class="product-name">
                                            <a href="<?php echo e(route('home.product', $cart_item['product']->slug)); ?>">
                                                <?php echo e($cart_item['product']->name); ?>

                                            </a>
                                        </td>
                                        <td class="product-price">
                                            <?php echo e(number_format($cart_item['product']->price)); ?>

                                        </td>
                                        <td class="product-quantity">
                                            <div class="cart-count-box" data-slug="<?php echo e($cart_item['product']->slug); ?>">
                                                <div class="cart-count-loading"></div>
                                                <i class="fa fa-plus cart-add-count" data-id="add"></i>
                                                <span class="cart-count"><?php echo e($cart_item['quantity']); ?></span>
                                                <i class="fa fa-minus cart-remove-count" data-id="remove"></i>
                                            </div>
                                        </td>
                                        <td class="product-total">
                                            <?php echo e(number_format($cart_item['product']->price * $cart_item['quantity'])); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="table-body-row">
                                        <td colspan="6" class="text-left">
                                            <p class="ml-5">
                                                سبد خرید خالی می باشد!
                                            </p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="total-section">
                        <table class="total-table">
                            <tbody>
                                <tr class="total-data">
                                    <td>
                                        <strong>جمع کل: </strong>
                                    </td>
                                    <td id="total-products-price">
                                        <?php echo e(number_format($total)); ?> تومان
                                    </td>
                                </tr>
                                <tr class="total-data">
                                    <td>
                                        <strong>هزینه ارسال: </strong>
                                    </td>
                                    <td data-shipping-price="<?php echo e(setting('shipping_price')); ?>">
                                        <?php echo e(number_format(setting('shipping_price'))); ?> تومان
                                    </td>
                                </tr>
                                <tr class="total-data">
                                    <td>
                                        <strong>هزینه نهایی: </strong>
                                    </td>
                                    <td id="total-cart-price">
                                        <?php echo e(number_format($total + setting('shipping_price'))); ?> تومان
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="coupon-section">
                            <label for="discount">ثبت کد تخفیف</label>
                            <input id="discount" name="discount" form="checkout" placeholder="کد تخفیف" <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> class="is-invalid" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>

                            <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="cart-buttons row">
                            <?php if(cart()->all()->count() > 0): ?>
                                <div class="col-4">
                                    <a href="<?php echo e(route('home.cart')); ?>" class="bordered-btn v-middle">بروزرسانی</a>
                                </div>
                                <form action="<?php echo e(route('order.checkout')); ?>" id="checkout" method="post" class="col-8">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="boxed-btn w-100 text-center">ثبت سفارش</button>
                                </form>
                            <?php else: ?>
                                <div class="col-12">
                                    <a href="<?php echo e(route('home.cart')); ?>" class="bordered-btn w-100 text-center">بروزرسانی</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end cart -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezamnk/ghoreyshi/resources/views/home/cart.blade.php ENDPATH**/ ?>